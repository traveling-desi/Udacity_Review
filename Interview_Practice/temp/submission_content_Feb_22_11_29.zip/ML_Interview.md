## Job Description ##

The Advanced Research Concepts (ARC) group focuses on research into next-generation cyber operations 
technology (NGCOT), primarily through the application of novel machine learning and behavior science 
techniques. All team members are encouraged to contribute new ideas and concepts towards both internal 
and external research and development. 

Roles and Responsibilities:
Research and develop statistical models to represent and automate cyber operations 
Design and develop software tools covering a broad spectrum of cyber security technologies
Participate in projects that combine many different programming languages including C, Python, HTML and Java on all types of Linux and Windows systems 
Support publication of research Required Education, Experience, and Abilities: 
Bachelor's Degree in Computer Science, Mathematics, Computer Engineering, Software Engineering or related discipline and 0-1 year of experience, or equivalent 
combination of education and experience. 
Proficient in development, debugging, and testing in Python 
Strong understanding of probability, statistics, and linear algebra 
Ability to obtain/maintain a DoD TS clearance

## Questions ##
------------------------------------------------------------------------------------------------------------------------------------------------------------------
1) We A/B tested two styles for a sign-up button on our company's product page. 100 visitors viewed page A, out of which 20 clicked on the button; whereas, 
70 visitors viewed page B, and only 15 of them clicked on the button. Can you confidently say that page A is a better choice, or page B? Why?
------------------------------------------------------------------------------------------------------------------------------------------------------------------
I guess the main reason to do an A/B test for the button is to figure out if a new style for the button will actually get more people to click on it or not 
therefore, the number of visitors clicking the button is more important than the number of people viewing the button relative to the number of people 
viewing the page
for style A - 20% clicked the button 
for style B - 21% clicked the button
therefore for this test we can say that style B is better but ofcourse, the sample size for both is too small to confirm this,
so a larger sample size would give a final conclusion

------------------------------------------------------------------------------------------------------------------------------------------------------------------
2) Can you devise a scheme to group Twitter users by looking only at their tweets? No demographic, geographic or other identifying information is available 
to you, just the messages they’ve posted, in plain text, and a timestamp for each message. In JSON format, they look like this:
{
 "user_id": 3,
 "timestamp": "2016-03-22_11-31-20",
 "tweet": "It's #dinner-time!"
}
Assuming you have a stream of these tweets coming in, describe the process of collecting and analyzing them, what transformations/algorithms you would apply, 
how you would train and test your model, and present the results ?
------------------------------------------------------------------------------------------------------------------------------------------------------------------
The question does not seem to indicate the criteria, the tweets will be grouped based on, so I will have to pick one, lets say I will group them based on 
the tone of their sentences, wether they are happy or sad or neutral, The algorithm I would use is word2vec I will convert the tweets as they come in 
to vectors and use a CNN trained on millions of words, to classify the tone of the tweets as they are coming in 

------------------------------------------------------------------------------------------------------------------------------------------------------------------
3) In a classification setting, given a dataset of labeled examples and a machine learning model you're trying to fit, describe a strategy to detect and prevent 
overfitting.
------------------------------------------------------------------------------------------------------------------------------------------------------------------
Let’s say we want to predict if a student will land a job interview based on her resume.
Now, assume we train a model from a dataset of 10,000 resumes and their outcomes.
Next, we try the model out on the original dataset, and it predicts outcomes with 100% accuracy
When we run the model on a new (“unseen”) dataset of resumes, we only get 50% accuracy
The idea is that If the algorithm is too complex or flexible (e.g. it has too many input features or it’s not properly regularized), it can end up 
“memorizing the noise” instead of finding the signal. This overfit model will then make predictions based on that noise. It will perform unusually well 
on its training data yet very poorly on new, unseen data.
to prevent overfitting we can use Cross-validation, the idea is to use the initial training data to generate multiple mini train-test splits. Then we use these 
splits to tune the model. In a standard k-fold cross-validation, we partition the data into k subsets, called folds. Then, we iteratively train the algorithm 
on k-1 folds while using the remaining fold as the test set (called the “holdout fold”).

------------------------------------------------------------------------------------------------------------------------------------------------------------------
4) Your team is designing the next generation user experience for your flagship 3D modeling tool. Specifically, you have been tasked with implementing a smart 
context menu that learns from a modeler’s usage of menu options and shows the ones that would be most beneficial. E.g. I often use Edit > Surface > Smooth 
Surface, and wish I could just right click and there would be a Smooth Surface option just like Cut, Copy and Paste. Note that not all commands make sense 
in all contexts, for instance I need to have a surface selected to smooth it. How would you go about designing a learning system/agent to enable this behavior?
------------------------------------------------------------------------------------------------------------------------------------------------------------------
it seems that the number of options from the context menu are finite and we can easily know when the user is most likely to use certain options from the menu
based on the context of the scene, for example if an object is selected then the user is more likely to use the 'edit' option. so the relation between 
what the user is selecting and the options in the menu is linear, therfore we can use a supervised learning algorithm to learn the absolute relation 
between what the user is selecting and what should appear in the context menu and then every time an object is selected the neural network 
is used to figure out what should appear in the menu

------------------------------------------------------------------------------------------------------------------------------------------------------------------
5) Give an example of a situation where regularization is necessary for learning a good model. How about one where regularization doesn't make sense ?
------------------------------------------------------------------------------------------------------------------------------------------------------------------
Regularization does not make sense if the model is not over-fitting but when the model is overfitting it will probably have poor prediction and generalization 
power, which means that it sticks too much to the data and the model has probably learned the background noise while being fit. This isn't of course acceptable.

------------------------------------------------------------------------------------------------------------------------------------------------------------------
6) Your neighborhood grocery store would like to give targeted coupons to its customers, ones that are likely to be useful to them. Given that you can access 
the purchase history of each customer and catalog of store items, how would you design a system that suggests which coupons they should be given? Can you 
measure how well the system is performing ?
------------------------------------------------------------------------------------------------------------------------------------------------------------------
dataset:
1) purchase history of each customer 
2) Catalog of store items
Objective:
Give targeted Coupons to the customers, that are likely to be useful to them
Design system that suggests which coupons they should be given and measure how well the system is performing ?
System:
from the customers purchase history we can get the items they bought and their zip codes, we will train a supervised learning algorithm on 
to learn the relation between the zip codes and the category of items bought from the store and then test the network on other items from 
the store that fall in the same categories as the ones bought from those zip codes and get the probability of purchase for each product 
and the store should send coupons to the zip codes that give out the highest probability for the items not bought by this zip code
if more items are bought later on for the same zipcodes then this means that the coupons are working

------------------------------------------------------------------------------------------------------------------------------------------------------------------
7) If you were hired for your machine learning position starting today, how do you see your role evolving over the next year? What are your long-term career goals, 
and how does this position help you achieve them ?
------------------------------------------------------------------------------------------------------------------------------------------------------------------
If I was hired for this role today, I would see my role evolving in a prgressive way where I would have to design machine learning models that continously adapt
to different cyber attacks. My long term career goals would be to make sure that AI is controlled and used to benefit humanity. This position will help 
me acheive this goal all ways to use the state of the art Deep learning algorithms to automate cyber security operations and make sure AI is used in the 
best interest of humanity.





















