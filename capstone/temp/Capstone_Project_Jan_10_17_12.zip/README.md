# Machine Learning Engineer Nanodegree
## Specializations
## Project: Capstone Project - Intrusion Detection System using machine learning classification algorithms.
The project code is included in Project_Intrusion_detection.ipynb file. This python jupyter notebook is created using python 3.6.
Softwares and libraries used in this project:
1. Pandas
2. Numpy
3. matplotlib
4. mpl_toolkits
5. scikit-learn
6. imbalanced-learn


