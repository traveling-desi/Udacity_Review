Folder Data: Contains the public dataset in csv format
Folder Plot: Contains the plots of each input feature against output feature

capstoneproject.py: Main code.
		Execution: python capstoneproject.py <filename>
		
CapstoneProjectReport.pdf: Project Report

proposal.pdf: Project proposal

Review link: https://review.udacity.com/#!/reviews/833119