import sys
import matplotlib.pyplot as plt
import time
import numpy
import csv
import os
from sklearn import preprocessing
from sklearn.neural_network import MLPClassifier
from sklearn.neural_network import MLPRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error
from sklearn.metrics import accuracy_score
from sklearn.metrics import f1_score

"""
CSV Data Columns::
0 Page total likes
1 Type
2 Category
3 Post Month	
4 Post Weekday	
5 Post Hour	
6 Paid	
7 Lifetime Post Total Reach
8 Lifetime Post Total Impressions
9 Lifetime Engaged Users
10 Lifetime Post Consumers
11 Lifetime Post Consumptions
12 Lifetime Post Impressions by people who have liked your Page
13 Lifetime Post reach by people who like your Page
14 Lifetime People who have liked your Page and engaged with your post	
15 comment	
16 like
17 share
18 Total Interactions
"""

"""
GLOBAL DATA
"""
plot_cols = numpy.matrix( [ [0,7], [0,8], [0,9], [0,10], [0,11], [0,12], [0,13], [0,14], [0,15], [0,18],
                            [1,7], [1,8], [1,9], [1,10], [1,11], [1,12], [1,13], [1,14], [1,15], [1,18],
                            [2,7], [2,8], [2,9], [2,10], [2,11], [2,12], [2,13], [2,14], [2,15], [2,18],
                            [3,7], [3,8], [3,9], [3,10], [3,11], [3,12], [3,13], [3,14], [3,15], [3,18],
                            [4,7], [4,8], [4,9], [4,10], [4,11], [4,12], [4,13], [4,14], [4,15], [4,18],
                            [5,7], [5,8], [5,9], [5,10], [5,11], [5,12], [5,13], [5,14], [5,15], [5,18],
                            [6,7], [6,8], [6,9], [6,10], [6,11], [6,12], [6,13], [6,14], [6,15], [6,18],
                          ] )
header = []
Data = []

"""
FUNCTION: mean_absolute_percentage_error
"""
def mean_absolute_percentage_error(y_true, y_pred):
    ret = numpy.mean( (numpy.abs(y_true - y_pred) / y_true) * 100 )
    return ret

"""
FUNCTION: plot_features
"""
def plot_features(filename):
    for i in range(plot_cols.shape[0]):
        print "plotting %d, %d" %(plot_cols[i,0], plot_cols[i,1])

        with open('dataset_Facebook.csv', 'r') as csvfile:
            plots = csv.reader(csvfile, delimiter=',')

            x = []
            y = []

            firstline = True

            for row in plots:
                if firstline:
                    xheader = row[plot_cols[i,0]]
                    yheader = row[plot_cols[i,1]]
                    firstline = False
                else:
                    if plot_cols[i,0] == 1:
                        if row[plot_cols[i,0]] == 'Photo':
                            x.append(0)
                        elif row[plot_cols[i,0]] == 'Status':
                            x.append(1)
                        elif row[plot_cols[i,0]] == 'Link':
                            x.append(2)
                        elif row[plot_cols[i,0]] == 'Video':
                            x.append(3)

                        if row[plot_cols[i,1]] == '':
                            y.append(0)
                        else:
                            y.append(int(row[plot_cols[i,1]]))
                    else:
                        x.append(int(row[plot_cols[i,0]]))

                        if row[plot_cols[i,1]] == '':
                            y.append(0)
                        else:
                            y.append(int(row[plot_cols[i,1]]))

            plotlabel = xheader + ' vs ' + yheader

            plt.figure()

            plt.xlabel(xheader)
            plt.ylabel(yheader)
            plt.title(xheader+' vs '+yheader)
            plt.legend()

            if plot_cols[i,0]  == 0:
                plt.scatter(x, y, label=plotlabel)
            else:
                plt.bar(x, y, label=plotlabel)

        directory = 'Images\\' + yheader
        filename = directory + "\\" + plotlabel + '.png'

        if not os.path.exists(directory):
            os.makedirs(directory)
        plt.savefig(filename)
        plt.close()

"""
FUNCTION: read_input_data_file
"""
def read_input_data_file(filename):
    for i in range(16):
        Data.append([])

    #with open('C:\udacity_ML_nanodefree\capstone\Facebook_metrics\dataset_Facebook.csv', 'r') as csvfile:
    with open(filename, 'r') as csvfile:
        completedata = csv.reader(csvfile, delimiter=',')

        firstline = True
        for row in completedata:
            if firstline:
                for index in range(16):
                    if index == 15:
                        index = index + 3
                    header.append(row[index])
                firstline = False
            else:
                for index in range(16):
                    if index == 1:
                        if row[index] == 'Photo':
                            Data[index].append(1)
                        elif row[index] == 'Status':
                            Data[index].append(2)
                        elif row[index] == 'Link':
                            Data[index].append(3)
                        elif row[index] == 'Video':
                            Data[index].append(4)
                    elif index == 15:
                        if row[index + 3] == '':
                            Data[index].append(0)
                        else:
                            Data[index].append(int(row[index + 3]))
                    else:
                        if row[index] == '':
                            Data[index].append(0)
                        else:
                            Data[index].append(int(row[index]))


"""
FUNCTION: binning
"""
def binning(bins):
    for j in [0, 7, 8, 9, 10, 11, 12, 13, 14, 15]:
        maxval = max(Data[j])
        minval = min(Data[j])

        factor = float((maxval - minval)) / bins

        for row in range(len(Data[j])):
            for k in range(bins):
                if (Data[j][row] >= (minval + k * factor) and Data[j][row] <= (minval + (k + 1) * factor)):
                    Data[j][row] = k + 1


"""
FUNCTION: Scaling
"""
def scaling_normalizing():
    scaler = preprocessing.StandardScaler()
    scaler.fit_transform(Data)

    normalizer = preprocessing.Normalizer()
    normalizer.fit_transform(Data)
"""
FUNCTION: train_n_fit
"""
def train_n_fit():
    #Extract Input features
    Input = Data[0:7]
    Input = numpy.transpose(Input)

    for i in range(7, 16):
        print "Building Model for Output Variable: %s" % (header[i])

        # Extract Output features
        Output = Data[i]

        # Building Model
        clf = MLPClassifier(solver='lbfgs', alpha=1e-5, hidden_layer_sizes=(7,), learning_rate='adaptive', max_iter=1000)

        trials = 10
        accuracy = []
        meanpercenterror = []
        precision = []
        iterations = []

        for trialnum in range(trials):
            #Split data into train and test data
            X_train, X_test, y_train, y_test = train_test_split(Input, Output, test_size=0.33)

            # Fit the model for the training data
            clf.fit(X_train, y_train)

            # Predict the Test Data Output
            y_pred = clf.predict(X_test)

            meanpercenterror.append(mean_absolute_percentage_error(y_test, y_pred))
            accuracy.append(accuracy_score(y_test, y_pred))
            precision.append(f1_score(y_test, y_pred, average='micro'))
            iterations.append(clf.n_iter_)

        print "Accuracy Score: %f" % (numpy.mean(accuracy))
        print "Absolute percent error %f" % (numpy.mean(meanpercenterror))
        print "Absolute precision score %f" % (numpy.mean(precision))
        print "Number of iterations %d" % (numpy.mean(iterations))

        directory = 'Images\\coef\\'
        filename = directory + "\\" + header[i] + '.png'

        fig, ax = plt.subplots(1, 1, figsize=(15, 6))
        ax.imshow(numpy.transpose(clf.coefs_[0]), cmap=plt.get_cmap("gray"), aspect="auto")
        plt.title(header[i])
        if not os.path.exists(directory):
            os.makedirs(directory)

        plt.xlabel('Neuron Input layer')
        plt.ylabel('Neuron Output layer')
        plt.savefig(filename)
        plt.close()



"""
FUNCTION: main
"""
def main(filename):
    #Plot input vs output features
    #plot_features(filename)

    #Read the input data from the input csv file
    read_input_data_file(filename)

    #Scaling the features
    scaling_normalizing()

    #number of buckets/bins into which the data should e divided
    bins = 10
    binning(bins)

    #Train the data and predict the test data
    train_n_fit()

if __name__=='__main__':
    sys.exit(main(sys.argv[-1]))