# Machine Learning Engineer Nanodegree
## Capstone Project
## Investment and Trading Capstone Project: Build a Stock Price Indicator

In this project, we build a stock price indicator which takes a specific stock's historical daily trading data as input and the output is this stock's price in the next trading day. Machine Learning models used in this study are Linear Regression, support vector machine, k-nearest neighbors, multilayer perceptron and random forest model.

The stock data are downloaded from Yahoo! Finance with ticker symbol GOOGL and BIDU.

To run the code used for this project, several packages are needed as listed in the requirements.txt file.
