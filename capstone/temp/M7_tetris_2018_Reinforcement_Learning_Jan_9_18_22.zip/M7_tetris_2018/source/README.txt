### Tetris with Reinforcement Learning - Amanda Kitagava ###

Software and libraries:
Python 2.7
numpy
pygame
pandas (Results)
matplotlib (Results)

Running:
python learner_run.py