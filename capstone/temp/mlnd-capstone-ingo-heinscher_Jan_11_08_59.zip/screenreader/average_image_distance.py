import keras
from keras.preprocessing import image
import sys
import numpy
import os

def image_read(image_path):  # reads in an image and turns it into a numpy array.
    image=keras.preprocessing.image.load_img(image_path,grayscale=True,target_size=(x,y))
    image=keras.preprocessing.image.img_to_array(image,"channels_last")
    return image

def image_distance(image_path1,image_path2): # computes how similar two given images are and gives back a value between 0 and roughly 
    sum_of_differences=0 # initialize
    image1=image_read(image_path1)
    image2=image_read(image_path2)
    for x1 in range(0,x):
        for y1 in range(0,y):
            difference=image1[x1][y1]-image2[x1][y1]
            difference=abs(difference)
            sum_of_differences+=difference
    return sum_of_differences

#main program

arguments=sys.argv

x=1024
y=576


path=arguments[1]
distances=[]

for image1 in sorted(os.listdir(path)):
        for image2 in sorted(os.listdir(path)):
            distance=image_distance(path+image1,path+image2)
            distances.append(distance)

divisor=len(distances)
summe=0
for element in distances:
    summe+=element

result=summe / divisor

print ("Average distance was ",result)




