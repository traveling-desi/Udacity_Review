import datetime
import time
import pyautogui


charlist=['shiftright',' ', '!', '"', '#', '$', '%', '&', "'", '(',               # a list of keys we could possibly press
        ')', '*', '+', ',', '-', '.', '/', '0', '1', '2', '3', '4', '5', '6', '7',
        '8', '9', ':', ';', '<', '=', '>', '?', '@', '[',']', '^', '_', '`',
        'a', 'b', 'c', 'd', 'e','f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o',
        'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '{', '|', '}', '~',
        'return']


def do_and_measure(action): # action is a tuple of (0,(x,y),z), with x and y being screen coordinates, 
                            # and z being the index of the desired key in charlist.
    time1=datetime.datetime.now()
    if action[0]==0:
        pyautogui.click(action[1][0],action[1][1])        
    else:
        if action==1:
            pyautogui.press(charlist[action[2]])
        else:
            print ("ERROR: action ",action," has not a valid categorization!",file=logfile)
    time2=datetime.datetime.now()
    total_time=time2-time1
    print ("Time to complete: ", total_time,file=logfile)
    return total_time

actions=[(0,(180,1050),0),(0,(180,100),0)]


logfile=open("logs/comparator.log","a")

for action in actions:
    do_and_measure(action)
    logfile.flush
    time.sleep(1)
