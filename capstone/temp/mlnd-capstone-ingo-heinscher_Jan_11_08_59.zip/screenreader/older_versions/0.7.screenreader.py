# Screenreader.py is the file that will contain almost all the python code for this project (except the
# publicly available modules that this file will load, the script that is used for benchmarking, and the
# evaluation program). It will define the neural networks as functions, as well as any algorithms
# required. It will also record the times when it starts and ends its runs

# Note to reviewer: Make sure scrot is installed if using this on Linux.

import PIL
import glob
import pyautogui
import keras
from keras.preprocessing import image
import numpy
import os
import cv2
import matplotlib
import random
import shutil
import sklearn
import h5py
import collections
import datetime
import json

def image_read(image_path):  # reads in an image and turns it into a numpy array.
#    time=str(datetime.datetime.now())
#    print ("image_read started at: ", time)
    image=keras.preprocessing.image.load_img(image_path,grayscale=True,target_size=(x,y))
    image=keras.preprocessing.image.img_to_array(image,"channels_last")
#    time=str(datetime.datetime.now())
#    print ("image_read ended at: ", time)
    return image

def image_merge(image1,image2):   # merges two images and appends them to an array of length 1, for easier use later.
#    time=str(datetime.datetime.now())
#    print ("image_merge started at: ", time)
    image_merged=numpy.concatenate((image1,image2),axis=2)
    image_array=list()
    image_array.append(image_merged)
    image_array=numpy.array(image_array)
#    time=str(datetime.datetime.now())
#    print ("image_merge ended at: ", time)
    return image_array

def image_distance(image_path1,image_path2): # computes how similar two given images are and gives back a value between 0 and roughly 
                                             # 768/4*1366/4*256=16,785,408 as a measure of that similarity - (0 = identical). 
#    time=str(datetime.datetime.now())
#    print ("image_distance started at: ", time)
    sum_of_differences=0 # initialize
    image1=image_read(image_path1)
    image2=image_read(image_path2)
    for x1 in range(0,x):
        for y1 in range(0,y):
            difference=image1[x1][y1]-image2[x1][y1]
            difference=abs(difference)
            sum_of_differences+=difference
#    time=str(datetime.datetime.now())
#    print ("image_distance ended at: ", time)
    return sum_of_differences
        
def action_selector_definition(): # defines the neural networks that tell us what the start screen, 
                              # combined with the task screen, should produce for an action and a prognosis for a new (greyscale) screen.
    # this one is supposed to take a state (which is a class of current_screens) and a task, and spit out a tuple of click and press
    # move in the right direction for reaching a new state (that is supposedly closer to the desired one).
    # input is a state image and the q_table.
    # output is an action, that is equivalent to (click(x,y,button), press(key))
    onedim_shape=x*y*2
    charspace=len(charlist)
    # our input layer:
    inputshape=keras.layers.Input(shape=(x,y,2))
    # Net for deciding click or press
    hidden_click_or_press1=keras.layers.Conv2D(filters=64,kernel_size=(64,64),use_bias=True)(inputshape)
    hidden_click_or_press2=keras.layers.MaxPool2D(pool_size=(2,2))(hidden_click_or_press1)
    hidden_click_or_press3=keras.layers.Conv2D(filters=32,kernel_size=(8,8),use_bias=True)(hidden_click_or_press2)
    hidden_click_or_press4=keras.layers.MaxPool2D(pool_size=(2,2))(hidden_click_or_press3)
    hidden_click_or_press5=keras.layers.Conv2D(filters=32,kernel_size=(8,8),use_bias=True)(hidden_click_or_press4)
    hidden_click_or_press6=keras.layers.MaxPool2D(pool_size=(2,2))(hidden_click_or_press5)
    hidden_click_or_press7=keras.layers.Conv2D(filters=32,kernel_size=(4,4),use_bias=True)(hidden_click_or_press6)
    hidden_click_or_press8=keras.layers.MaxPool2D(pool_size=(2,2))(hidden_click_or_press7)
    hidden_click_or_press9=keras.layers.Flatten()(hidden_click_or_press8)
    output_click_or_press=keras.layers.Dense(2)(hidden_click_or_press9)
    click_or_press_selector_net=keras.models.Model(inputs=inputshape,outputs=output_click_or_press)
    #click_or_press_selector_net.summary()
    print("Compiling click or press selector model.")
    click_or_press_selector_net.compile(optimizer='rmsprop', loss='categorical_crossentropy', metrics=['accuracy'])
    print ("Click or press selector model compiled.")
    # Net branch for click
    hiddenclick1=keras.layers.Conv2D(filters=64,kernel_size=(64,64),use_bias=True)(inputshape)
    hiddenclick2=keras.layers.MaxPool2D(pool_size=(2,2))(hiddenclick1)
    hiddenclick3=keras.layers.Conv2D(filters=32,kernel_size=(8,8),use_bias=True)(hiddenclick2)
    hiddenclick4=keras.layers.MaxPool2D(pool_size=(2,2))(hiddenclick3)
    hiddenclick5=keras.layers.Conv2D(filters=32,kernel_size=(4,4),use_bias=True)(hiddenclick4)
    hiddenclick6=keras.layers.MaxPool2D(pool_size=(2,2))(hiddenclick5)
    hiddenclick7=keras.layers.Conv2D(filters=32,kernel_size=(2,2),use_bias=True)(hiddenclick6)
    hiddenclick8=keras.layers.MaxPool2D(pool_size=(2,2))(hiddenclick7)
    hiddenclick9=keras.layers.Flatten()(hiddenclick8)
    outputclick=keras.layers.Dense(2)(hiddenclick9)
    click_selector_net=keras.models.Model(inputs=inputshape,outputs=outputclick)
    #click_selector_net.summary()
    print("Compiling selector model.")
    click_selector_net.compile(optimizer='rmsprop', loss='mean_squared_error', metrics=['accuracy'])
    print ("Click selector model compiled.")
    # Net branch for press
    hiddenpress1=keras.layers.Conv2D(filters=64,kernel_size=(64,64),use_bias=True)(inputshape)
    hiddenpress2=keras.layers.MaxPool2D(pool_size=(2,2))(hiddenpress1)
    hiddenpress3=keras.layers.Conv2D(filters=64,kernel_size=(8,8),use_bias=True)(hiddenpress2)
    hiddenpress4=keras.layers.MaxPool2D(pool_size=(2,2))(hiddenpress3)
    hiddenpress5=keras.layers.Conv2D(filters=32,kernel_size=(8,8),use_bias=True)(hiddenpress4)
    hiddenpress6=keras.layers.MaxPool2D(pool_size=(2,2))(hiddenpress5)
    hiddenpress7=keras.layers.Conv2D(filters=16,kernel_size=(2,2),use_bias=True)(hiddenpress6)
    hiddenpress8=keras.layers.MaxPool2D(pool_size=(2,2))(hiddenpress7)
    hiddenpress9=keras.layers.Flatten()(hiddenpress8)
    outputpress=keras.layers.Dense(len(charlist))(hiddenpress9)
    press_selector_net=keras.models.Model(inputs=inputshape,outputs=outputpress)
   # press_selector_net.summary()
    print("Compiling press selector model.")
    press_selector_net.compile(optimizer='rmsprop', loss='categorical_crossentropy', metrics=['accuracy'])
    print ("press selector model compiled.")
    # put it all together. 
    netlist=[click_or_press_selector_net,click_selector_net,press_selector_net]
    return netlist


def train_selectors(click_or_press_selector_net,click_selector_net,press_selector_net):
    # this is more complicated. We have really high number of potential states right now... that is too many to do regular q_learning. 
    # that is why we will create a few sample rewards, that is, a regular q-table for a few state-action pairs, and generalize that by 
    # feeding this as training data into a neural network.
    # We will be going through the q_table state by state for each task, 
    # determine which actions per given state/task-pair are best based in that state and task combination,
    # and feed that tuple of task, state and action to the neural net, the first two as x, the action as y.
    time=str(datetime.datetime.now())
    print ("train_selectors started at",time)
    global q_table    # q_table is of shape {task:{state:{action:reward},state2{},...}} this function doesn't change this, 
                      # so global would not be strictly required.
    global recent_q_table    # recent_q_table is like q_table, but only for the current training cycle.
    training_outputs=list()
    training_inputs=list()
    for q_task in recent_q_table:
        task_image=image_read("tasks/"+q_task)
        for q_state in recent_q_table[q_task]:
            best_action=choose_random_action()
            state_image=image_read(q_state)
            task_and_state_image=numpy.concatenate((task_image,state_image),axis=2)
            training_inputs.append(task_and_state_image)
            for q_action in recent_q_table[q_task][q_state]:
                comparator=-1*((x*y*256)+1)    # this value is below what can ever happen for starting_reward.
                reward=recent_q_table[q_task][q_state][q_action]       
                if reward>comparator:
                    comparator=reward
                    best_action=q_action
                training_outputs.append(best_action)
    # training inputs are tasks and states, outputs are actions to be taken
    training_inputs=numpy.array(training_inputs)
    click_or_press_array=list()
    click_array=list()
    press_array=list()
    for element in training_outputs:
        if element[0]==0:
            click_or_press_array.append([1,0])
        else:
            if element[0]==1:
                click_or_press_array.append([0,1])
            else:
                print ("ERROR! click or press array could not be set!")
        click_array.append(element[1])
        press_array.append(element[2])           
    click_or_press_array=numpy.array(click_or_press_array)
    click_array=numpy.array(click_array)
    press_array=numpy.array(press_array)                # this whole section is for making the format digestible for .fit.
    press_array=keras.utils.np_utils.to_categorical(press_array,num_classes=len(charlist))
    epochs=10                                           # we only train for 3 epochs, but repeatedly, so in the end, this will still be fine
    click_or_press_selector_net.fit(x=training_inputs,y=click_or_press_array,epochs=epochs, batch_size=2, verbose=0, validation_split=0.1, shuffle=True)
    click_selector_net.fit(x=training_inputs, y=click_array,epochs=epochs, batch_size=2, verbose=0, validation_split=0.1, shuffle=True)
    press_selector_net.fit(x=training_inputs, y=press_array,epochs=epochs, batch_size=2, verbose=0, validation_split=0.1, shuffle=True)
    click_or_press_selector_net.save("saved_models/"+str(program_instance)+"click_or_press_selector-"+str(counter)+".h5") # save the trained model
    click_selector_net.save("saved_models/"+str(program_instance)+"click_selector-"+str(counter)+".h5") # save the trained model
    press_selector_net.save("saved_models/"+str(program_instance)+"press_selector-"+str(counter)+".h5") # save the trained model
    recent_q_table.clear()   # this makes sure that we won't have to train anything next time that we have seen already. 
                             # small loss of information, big win in terms of processing speed.
    taskfiles=sorted(os.listdir("tasks/"))         #  this reinitializes recent_q_table with the list of tasks
    recent_q_table.clear()
    for task in taskfiles:
        recent_q_table.update({task:{}})
    time=str(datetime.datetime.now())
    print ("train_selectors ended at ",time)

def q_learning(task,current_state): # does all the reinforcement learning 
    # The idea is to let the program act randomly until there is a state change, then reward this, 
    # but also save the random actions that led there. The whole trail of actions needs to be saved, and those closest to the reward-worthy 
    # event get the highest reward. A saved action sequence only ends when a task is found to be finished, 
    # which also triggers a big reward.
    # This way, we build a q-table that will not determine the action directly, but which is fed into the neural net for determining actions,
    # along with the state in which it was taken.
#    time=str(datetime.datetime.now())
#    print ("q_learning started at: ", time)
    global q_table           # these variables are used elsewhere, too - but we don't want to pass them through all the functions
    global actionlist        # so using global is more convenient.
    global recent_q_table
    globalcounter=counter
    globaltask = task
    globaltask=globaltask.replace("tasks/","")
    # How different is the current screen's distance from the task  from the previous state's distance from the task?
    last_state=current_state
    reverse_actionlist=actionlist
    if actionlist != {}:
        reverse_actionlist=sorted(reverse_actionlist.items(),reverse=True)
        last_state=reverse_actionlist[0]
        last_state=last_state[0]
    distance_from_task=image_distance(task,current_state)+likeness
    starting_reward=image_distance(task,last_state)-distance_from_task # if there is improvement, reward, otherwise cost 
                                                                       # (the above +likeness makes sure stagnation is punished)
    starting_reward=int(starting_reward)
   # print ("starting reward is:", starting_reward)
    reward=starting_reward
    for actionlist_state in reverse_actionlist:           # we start with the last action
        state=actionlist_state[0]
        action=actionlist_state[1]
        for q_task in q_table:
            if q_task==globaltask:                                # if the q_task is our current task...
                if state in q_table[globaltask] and state != []:                     # we update our q_table with the reward
                    if action in q_table[globaltask][state]:
                        q_table[globaltask][state][action]+=reward
                    else:
                        q_table[globaltask][state].update({action:reward})
                else: 
                   q_table[globaltask].update({state:{action:reward}})
        for q_task in recent_q_table:                                  # and now we do the same updating with the recent_q_table, 
                                                                       # but with the rewards already computed in q_table
            if q_task==globaltask:
                total_reward=q_table[globaltask][state][action]
                if state in recent_q_table[globaltask] and state != []:                     
                    if action in recent_q_table[globaltask][state]:
                        recent_q_table[globaltask][state][action]=total_reward
                    else:
                        recent_q_table.update({globaltask:{state:{action:total_reward}}})
                else: 
                    recent_q_table.update({globaltask:{state:{action:total_reward}}})
        reward=reward*0.9
    # save the q_table into a file
    q_tablefile=open("qtables/q_table"+str(program_instance)+"-"+str(globaltask)+"-"+str(globalcounter)+".txt","a")
    print ("q_table: ",q_table,file=q_tablefile)
    q_tablefile.close()
#    time=str(datetime.datetime.now())
#    print ("q_learning ended at: ", time)


def success_detector(task, current_state): # This function just tells us if the current screen is reasonably 
                                            # close to the task screen so that saying that we have succeded is in order. 
                                            # Uses the classifier defined in def classifier_detection, as trained by def train_classifiera
#    time=str(datetime.datetime.now())
#    print ("success_detector started at: ", time)
    global actionlist
    detection=image_distance(task,current_state)
    if detection <= likeness:                  
        success=True   
        actionlist.clear
    else: 
        success=False
    q_learning(task,current_state)
#    time=str(datetime.datetime.now())
#    print ("success_detector ended at: ", time)
    return success



def determine_state(current_screen):  
#    time=str(datetime.datetime.now())
#    print ("determine_state started at: ", time)
    ### compares the current screen to the existing states. If it matches one, this is our state. If it doesn't, we have to define a new state.
    ### if it does exist, it uses the one with the least distance from the current screen (in case of a tie, the first found is used).
    returned_state=current_screen
    for states in os.listdir("states/"):
        distance=image_distance("states/"+states,current_screen)
        if distance <= likeness:
            returned_state="states/"+states
    if returned_state==current_screen:
        shutil.copy(current_screen,"states/")               # use current_screen as our state
        returned_state=returned_state.replace("screenshots/","states/") 
    #print ("returned_state: ",returned_state)
#    time=str(datetime.datetime.now())
#    print ("determine_state ended at: ", time)
    return returned_state


def choose_random_action():
#    time=str(datetime.datetime.now())
#    print ("choose_random_action started at: ", time)
    # first decide if it is a mouseclick or a key pressed.
    if random.random()>0.333:   # in about two thirds of the time, we choose to use the mouse
        click_or_press=0
        click_x=random.random()*screensize[0]    
        click_x=int(click_x)
        click_y=random.random()*screensize[1]
        click_y=int(click_y)
        click=(click_x,click_y)
        press=0  # shiftright, which is basically "do nothing". We are never going to execute this here anyway, it's just for ease of reading.
    else:
        click_or_press=1
        click=(0,0)
        press=random.randint(0,len(charlist)-1)
    action=(click_or_press,click,press)
#    time=str(datetime.datetime.now())
#    print ("choose_random_action ended at: ", time)
    return action

def action_selector(task,current_screen):        # selects the next action based on the current screen
                                                 # action (which is also a policy) is a tuple of :
                                                 # click_or_press: type of action 0=click, 1=char
                                                 # click (x,y) (click left at these coordinates)
                                                 # press (one character from charlist, tuple contains index of that char)
#    time=str(datetime.datetime.now())
#    print ("action_selector started at ",time)
    state=current_screen
    state.replace("screenshots/","states/")
    current_state=state
    if random.random() <= epsilon:
        action=choose_random_action()
        #print ("The following random action was selected:",action)
    else:
        task_image=image_read(task)
        current_screen_image=image_read(current_screen)
        input_image_array=image_merge(task_image,current_screen_image)
        click_or_press_r=click_or_press_selector_net.predict(input_image_array)
        if click_or_press_r[0][0] <= click_or_press_r[0][1]:
            click_or_press=int(0)
        else:
            click_or_press=int(1)
        if click_or_press==0:
            click_array=click_selector_net.predict(input_image_array)
            if click_array[0][0]<0:
                click_array[0][0]=int(0)
            if click_array[0][0]>1023:
                click_array[0][0]=int(1023)
            if click_array[0][1]<0:
                click_array[0][1]=int(0)
            if click_array[0][1]>576:
                click_array[0][1]=int(576)
            click=(int(click_array[0][0]),int(click_array[0][1]))
            press=0     # this is a shiftleft, so effectively nothing.
        else:
            if click_or_press==1:
                click=(0,0)
                pressarray=press_selector_net.predict(input_image_array)
                press=int(pressarray[0][0])
                if press<=0:
                    press=0
                if press>len(charlist)-1:
                    press=0
        action=(click_or_press,click,press)
        #print ("The neural nets chose the following action: ",action)
#    time=str(datetime.datetime.now())
#    print ("action_selector ended at ",time)
    return action

def do_it(current_state,action): #reads the action list and carries it out.
#    time=str(datetime.datetime.now())
#    print ("do_it started at: ", time, "for action: ",action)
    if action[0]==0:
        pyautogui.click(x=action[1][0],y=action[1][1],button="left")

    else:
        if action[0]==1:
            if action[2]>-1 and action[2]<len(charlist):
                key=charlist[action[2]]
                pyautogui.press(key)
            else:
                print ("Error: action[2] was out of bounds. Value is: ",action[2])
        else:
            print ("ERROR! action[0] not valid!")
    # save action in current actionlist:
    global actionlist     
    actionlist.update({current_state:action})
#    time=str(datetime.datetime.now())
#    print ("do_it ended at: ", time)



def get_current_screen(program_instance,tasknumber,counter):                                  # putscurrent screen in filename, returns filename
#    time=str(datetime.datetime.now())
#    print ("get_current_screen started at: ", time)
    savename="screenshots/"+str(program_instance)+"-"+str(tasknumber)+"-"+str(counter)+".png"  # defines the name of the next screenshot
    current_screen=pyautogui.screenshot(savename)                                                    # saves the current screen for later use.
#    time=str(datetime.datetime.now())
#    print ("get_current_screen ended at: ", time)
    return savename                                                                                  # gives back path and filename of screenshot


# main program starts here
pyautogui.FAILSAFE = False
time=str(datetime.datetime.now())
print ("PROGRAM started at ",time)
for directory in ["screenshots/","states/","target_folder/"]:
    if os.listdir(directory) != []:
        for files in os.listdir(directory):
            os.remove(directory+files)
q_table=collections.OrderedDict()                                                 # These are two ordered dictionaries of shape 
recent_q_table=collections.OrderedDict()                                          # {task1: {state_1:(action_1:qvalue_1), (action_2:qvalue_2), 
                                                                                  # action_3,...action_n),state_2:()} state_2:... state_n}, 
                                                                                  # task_2, 
                                                                                  # with action_n being of shape (click, press)
                                                                                  # this one gets updated every time an action 
                                                                                  # is taken. the "recent" version only contains stuff for the
                                                                                  # current cycle and is reset after training.
screensize=pyautogui.size()
x=1024                                                                            # Defines how large are the screenshots after reading them from
y=576                                                                             # the files that have been stored to the disk.
likeness=x*y*256*0.075                                                            # a measure for how similar two images have to be 
                                                                                  # to be considered the same state, derived from observations.
                                                                                  # that is only an approximation, of course. But we have to 
                                                                                  # save resources
charlist=['shiftright',' ', '!', '"', '#', '$', '%', '&', "'", '(',               # a list of keys we could possibly press
        ')', '*', '+', ',', '-', '.', '/', '0', '1', '2', '3', '4', '5', '6', '7',
        '8', '9', ':', ';', '<', '=', '>', '?', '@', '[',']', '^', '_', '`',        
        'a', 'b', 'c', 'd', 'e','f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o',
        'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '{', '|', '}', '~',
        'return']
screenshot_array=""
actionlist=collections.OrderedDict()                                              # This is a dictionary of actions that reads like 
actionlist={}                                                                     # {statename_1:action_1}, {statename_1:action_2},... 
                                                                                  # {statename_n:action_n}]
                                                                                  # this one gets appended when an action is taken, 
                                                                                  # and reset every time a task is achieved. 
program_instance = int(random.random()*4294967296)                                # A probably unique number for this program's run, 
                                                                                  # used for identifying screenshots later.
path="tasks/"                                                                     # path of the task files
taskfiles = sorted(os.listdir(path))                                              # read names of files that describe our tasks into a list
for task in taskfiles:                                                            # and initialize the q_table and the recent_q_table
    q_table.update({task:{}})
    recent_q_table.update({task:{}})
tasks=[]                                                                          # Initialize the tasks list
netlist=action_selector_definition()
click_or_press_selector_net=netlist[0]
click_selector_net=netlist[1]
press_selector_net=netlist[2]
epsilon=1.0                                                                       # initialize epsilon ro RL, set it to 1.  set to 0 for testing
                                                                                  # So initially, we act completely randomly.
counter=-1                                                                        # for naming the classifier mode savefile...
for task in taskfiles:                                                            # work through all tasks.
    success=False                                                                 # At start of a task, we probably haven't succeeded yet.
    counter=-1                                                                    # To be used later in the while loop.
    while success==False:                                                         # for each task, work until the task is done.
        counter += 1                                                              # increase the counter.
        current_screen=get_current_screen(program_instance,task,counter)          # make a screenshot of the current screen.
        current_state=determine_state(current_screen)                             # do we have a state that is EQUAL to our current screen?
                                                                                  # if not, our current screen is a new state
        success=success_detector(path+task,current_state)                         # check if we have already reached our goal
        if success==False:                                                        # if we are not done yet:
            action=action_selector(path+task,current_state)                       # choose to do something that might improve our situation 
            do_it(current_state,action)                                           # carry out that action.
            current_screen=get_current_screen(program_instance,task,counter)
        else:
            if success == True:                                                       # if we are successful:
                shutil.copy(current_screen,"target_folder/")                          # save current screen to target folder
        if counter % 200==0 and counter > 0:                                      # every 100 cycles, train nn with q_table, tasks and states.
            print ("Counter: ",counter)
            train_selectors(click_or_press_selector_net,click_selector_net,press_selector_net)  # train selector with current q_table
            epsilon=epsilon*0.99                                                  # and reduce epsilon to 99% of current value.
            print ("Epsilon:",epsilon) # for dev purposes
time=str(datetime.datetime.now())
print ("PROGRAM ended at ",time)
