# Screenreader.py is the file that will contain almost all the python code for this project (except the
# publicly available modules that this file will load, the script that is used for benchmarking, and the
# evaluation program). It will define the neural networks as functions, as well as any algorithms
# required. It will also record the times when it starts and ends its runs

# Note to reviewer: Make sure scrot is installed if using this on Linux.

import PIL
import glob
import pyautogui
import keras
from keras.preprocessing import image
import numpy
import os
import cv2
import matplotlib
import random
import shutil
import sklearn
import h5py
import collections
import datetime
import json

def image_read(image_path):  # reads in an image and turns it into a numpy array.
    image=keras.preprocessing.image.load_img(image_path,grayscale=True,target_size=(x,y))
    image=keras.preprocessing.image.img_to_array(image,"channels_last")
    time=str(datetime.datetime.now())
    return image

def image_merge(image1,image2):   # merges two images and appends them to an array of lenght 1, for easier use later.
    image_merged=numpy.concatenate((image1,image2),axis=2)
    image_array=list()
    image_array.append(image_merged)
    image_array=numpy.array(image_array)
    return image_array

def image_distance(image_path1,image_path2): # computes how similar two given images are and gives back a value between 0 and roughly 
                                             # 768/4*1366/4*256=16,785,408 as a measure of that similarity - (0 = identical). 
    sum_of_differences=0 # initialize
    image1=image_read(image_path1)
    image2=image_read(image_path2)
    for x1 in range(0,x):
        for y1 in range(0,y):
            difference=image1[x1][y1]-image2[x1][y1]
            difference=abs(difference)
            sum_of_differences+=difference
    return sum_of_differences
        
def action_selector_definition(): # defines the neural network that tells us what the start screen, 
                              # combined with the task screen, should produce for an action.
    # this one is supposed to take a state (which is a class of current_screens) and a task, and spit out a tuple of click, scroll, press to 
    # move in the right direction for reaching a new state (that is supposedly closer to the desired one).
    # input is a state image and the q_table.
    # output is an action, that is, click(x,y,button), scroll(y), and press(key), with only one of them being usually set - 
    # but that is not necessarily so, as our neural net might identify patterns that go beyond that. We'll see.
    onedim_shape=x*y*2
    charspace=len(charlist)
    # our input layer:
    inputshape=keras.layers.Input(shape=(x,y,2))
    # Net branch for move_to
    hiddenmoveto1=keras.layers.Conv2D(filters=4,kernel_size=(4,4),use_bias=True)(inputshape)
    hiddenmoveto2=keras.layers.MaxPool2D(pool_size=(2,2))(hiddenmoveto1)
    hiddenmoveto3=keras.layers.Conv2D(filters=2,kernel_size=(4,4),use_bias=True)(hiddenmoveto2)
    hiddenmoveto4=keras.layers.MaxPool2D(pool_size=(2,2))(hiddenmoveto3)
    hiddenmoveto5=keras.layers.Conv2D(filters=1,kernel_size=(4,4),use_bias=True)(hiddenmoveto4)
    hiddenmoveto6=keras.layers.MaxPool2D(pool_size=(2,2))(hiddenmoveto5)
    hiddenmoveto7=keras.layers.Conv2D(filters=1,kernel_size=(4,4),use_bias=True)(hiddenmoveto6)
    hiddenmoveto8=keras.layers.MaxPool2D(pool_size=(2,2))(hiddenmoveto7)
    hiddenmoveto9=keras.layers.Flatten()(hiddenmoveto8)
    outputmoveto=keras.layers.Dense(2)(hiddenmoveto9)
    # Net branch for click
    hiddenclick1=keras.layers.Conv2D(filters=1,kernel_size=(16,16),use_bias=True)(inputshape)
    hiddenclick2=keras.layers.MaxPool2D(pool_size=(2,2))(hiddenclick1)
    hiddenclick3=keras.layers.Conv2D(filters=1,kernel_size=(8,8),use_bias=True)(hiddenclick2)
    hiddenclick4=keras.layers.MaxPool2D(pool_size=(2,2))(hiddenclick3)
    hiddenclick5=keras.layers.Conv2D(filters=1,kernel_size=(4,4),use_bias=True)(hiddenclick4)
    hiddenclick6=keras.layers.MaxPool2D(pool_size=(2,2))(hiddenclick5)
    reshapeclick=keras.layers.Flatten()(hiddenclick6)
    outputclick=keras.layers.Dense(1)(reshapeclick)
    # Net branch for press
    hiddenpress1=keras.layers.Conv2D(filters=1,kernel_size=(16,16),use_bias=True)(inputshape)
    hiddenpress2=keras.layers.MaxPool2D(pool_size=(2,2))(hiddenpress1)
    hiddenpress3=keras.layers.Conv2D(filters=1,kernel_size=(8,8),use_bias=True)(hiddenpress2)
    hiddenpress4=keras.layers.MaxPool2D(pool_size=(2,2))(hiddenpress3)
    hiddenpress5=keras.layers.Conv2D(filters=1,kernel_size=(4,4),use_bias=True)(hiddenpress4)
    hiddenpress6=keras.layers.MaxPool2D(pool_size=(2,2))(hiddenpress5)
    reshapepress=keras.layers.Flatten()(hiddenpress6)
    outputpress=keras.layers.Dense(1)(reshapepress)
    # put it all together.
    action_selector=keras.models.Model(inputs=inputshape,outputs=[outputmoveto,outputclick,outputpress])
    action_selector.summary()
    print("Compiling selector model.")
    action_selector.compile(optimizer='rmsprop', loss='mean_squared_error', metrics=['accuracy'])
    print ("Selector model compiled.")
    return action_selector

def train_selector(action_selector):
    # this is more complicated. We have really high number of potential states right now... that is too many to do regular q_learning. 
    # that is why we will create a few sample rewards, that is, a regular q-table for a few state-action pairs, and generalize that by 
    # feeding this as training data into a neural network.
    # We will be going through the q_table state by state for each task, 
    # determine which actions per given state/task-pair are best based in that state and task combination,
    # and feed that tuple of task, state and action to the neural net, the first two as x, the action as y.
    time=str(datetime.datetime.now())
    print ("train_selector started at",time)
    global q_table    # q_table is of shape {task:{state:{action:reward},state2{},...}} this function doesn't change this, 
                      # so global would not be strictly required.
    global recent_q_table    # recent_q_table is like q_table, but only for the current training cycle.
    training_outputs=list()
    training_inputs=list()
    for q_task in recent_q_table:
        task_image=image_read("tasks/"+q_task)
        for q_state in recent_q_table[q_task]:
            state_image=image_read(q_state)
            task_and_state_image=numpy.concatenate((task_image,state_image),axis=2)
            training_inputs.append(task_and_state_image)
            for q_action in recent_q_table[q_task][q_state]:
                comparator=-1000000000000
                reward=recent_q_table[q_task][q_state][q_action]       
                if reward>comparator:
                    comparator=reward
                    best_action=q_action
            best_action=translate_action(best_action)
            training_outputs.append(best_action)
        # training inputs are tasks and states, outputs are actions to be taken
    training_inputs=numpy.array(training_inputs)
    training_outputs=numpy.array(training_outputs)
    move_to_array=list()
    click_array=list()
    press_array=list()
    for element in training_outputs:
        move_to_array.append(element[0][0])
        click_array.append(element[1])
        press_array.append(element[2])           
    move_to_array=numpy.array(move_to_array)
    click_array=numpy.array(click_array)
    press_array=numpy.array(press_array)                # this whole section is for making the format digestible for .fit.
    epochs=3                                            # we only train for 3 epochs, but repeatedly, so in the end, this will still be fine
    action_selector.fit(x=training_inputs, y=[move_to_array,click_array,press_array],epochs=epochs, batch_size=2, verbose=0, validation_split=0.1, shuffle=True)
    action_selector.save("saved_models/"+str(program_instance)+"action_selector-"+str(counter)+".h5") # save the trained model
    recent_q_table.clear()   # this makes sure that we won't have to train anything next time that we haven't seen yet. 
                             # small loss of information, big win in terms of processing speed.
    taskfiles=sorted(os.listdir("tasks/"))         #  this reinitializes recent_q_table with the list of tasks
    for task in taskfiles:
        recent_q_table.update({task:{}})
    time=str(datetime.datetime.now())
    print ("train_selector ended at ",time)

def q_learning(task,distance): # does all the reinforcement learning 
    # The idea is to let the program act randomly until there is a state change, then reward this (mildly), 
    # but also save the random actions that led there. The whole trail of actions needs to be saved, and those closest to the reward-worthy 
    # event get the highest reward. A saved action sequence only ends when a task is found to be finishedstate,action, 
    # which also triggers a big reward.
    # This way, we build a q-table that will not determine the action directly, but which is fed into the neural net for determining actions,
    # along with the state in which it was taken.

    global q_table           # these variables are used elsewhere, too - but we don't want to pass them through all the functions
    global actionlist        # so using global is more convenient.
    global recent_q_table
    globaltask = task
    globalcounter = counter  
    starting_reward = -1*(distance-likeness)     # So if there was success, we'll have a positive value, otherwise a negative one.
    starting_reward=int(starting_reward[0])
    if starting_reward < 0:
        starting_reward = starting_reward // (likeness) ### negative rewards can easily go up and beyond, so let us limit their impact.
    reward=starting_reward
    reverse_actionlist=sorted(actionlist.items(),reverse=True)
    for actionlist_state in reverse_actionlist:           # we start with the last action
        state=actionlist_state[0]
        action=actionlist_state[1]

        for q_task in q_table:
            if q_task==task:                                # if the q_task is our current task...
                if state in q_table[task] and state != []:                     # we update our q_table with the reward
                    if action in q_table[task][state]:
                        q_table[task][state][action]+=reward
                    else:
                        q_table[task][state].update({action:reward})
                else: 
                    q_table[task].update({state:{action:reward}})
        for q_task in recent_q_table:                                  # and now we do the same updating with the recent_q_table, 
                                                                       # but with the rewards already computed in q_table
            if q_task==task:
                total_reward=q_table[task][state][action]
                if state in recent_q_table[task] and state != []:                     
                    if action in recent_q_table[task][state]:
                        recent_q_table[task][state][action]=total_reward
                    else:
                        recent_q_table[task][state].update({action:total_reward})
                else: 
                    recent_q_table[task].update({state:{action:total_reward}})
        reward=reward*0.9


    if starting_reward >= 0:  # and finally, if we have had success with our action to reach the task
        actionlist.clear()  # we empty our global actionlist
    # save the q_table into a file
    q_tablefile=open("qtables/q_table"+str(program_instance)+"-"+str(globaltask)+"-"+str(globalcounter)+".txt","a")
    print ("q_table: ",q_table,file=q_tablefile)
    q_tablefile.close()



def success_detector(task, current_screen): # This function just tells us if the current screen is reasonably 
                                            # close to the task screen so that saying that we have succeded is in order. 
                                            # Uses the classifier defined in def classifier_detection, as trained by def train_classifiera
    detection=image_distance("tasks/"+task,current_screen)
    if detection <= likeness:                  
        success=True    
        # and now some additional q-learning because we had success.
    else: 
        success=False
    q_learning(task,detection)
    return success



def determine_state(current_screen):
    current_best_detection = 16785408   # initialize as highest possible distance
    current_best = ""   # initialize
    ### compares the current screen to the existing states. If it matches one, this is our state. If it doesn't, we have to define a new state.
    ### if it does exist, it uses the one with the least distance from the current screen (in case of a tie, the first found is used).
    states=os.listdir("states/")
    if states == []:                                          # if there are no states yet, 
        shutil.copy(current_screen,"states/")               # use current_screen as our first state
        states=os.listdir("states/")                        # and of course re-read the list of states
    for state in states:
        detection=image_distance("states/"+state,current_screen)
        if detection <= likeness:   # if the images have an image_distance of 50,000 or less (arbitrarily chosen number)
            # then this current_screen belongs to state "state"
            if detection < current_best_detection:
                current_best = "states/"+state
                current_best_detection=detection
        else:
             # if it is not like any known state, we need a new state, defined by the contents of current_screen.
             shutil.copy(current_screen,"states/")
             current_state_filename=current_screen.replace("screenshots/","states/")
             current_best = current_state_filename
    returned_state = current_best
    return returned_state

def choose_random_action():
    move_to_x=random.random()*screensize[0]
    move_to_x=int(move_to_x)
    move_to_y=random.random()*screensize[1]
    move_to_y=int(move_to_y)
    move_to=[move_to_x,move_to_y]          
    click=random.choice(["left","middle","right"])
    press=random.choice(charlist)
    action=[move_to,click,press]
    return action

def translate_action(action): # translates actions from what the neural net puts out to 
                              # something the rest of the program can understand, and vice verse
    action0=action[0]
    action1=action[1]
    action2=action[2]
    # first, let us find out what we have here: an action coming from the neural net or an action going to it?
    if type(action[1]) == numpy.ndarray:
        # this means we want to make something understandable out of the neural net's output.
        # the coordinates to move the mouse to.
        action0=[action0[0][0],action0[0][1]] # getting rid of some brackets here
        if action0[0]<0:
            action0[0]=0
        if action0[1]<0:
            action0[1]=0
        if action0[0]>screensize[0]:
            action0[0]=screensize[0]
        if action0[1]>screensize[1]:
            action0[1]=screensize[1]
        action0[0]=int(action0[0])
        action0[1]=int(action0[1])
        action0=(action0[0],action0[1]) # turn this into a tuple
        # the mousebutton to be pressed.
        action1=int(action1) # now we have the number that the neural net gave us back into one of "left", "middle", "right" or "None"
        if action1>=0 and action1<1:
            action1=str(action1)
            action1="left"
        else:
            if action1>=1 and action1<2:
                action1=str(action0)
                action1="middle"
            else:
                if action1>=2 and action1 < 3:
                    action1=str(action1)
                    action1="right"
                else:
                    action1="None"
        action2=action2.astype(int)
        action2=int(action2) # and here, we translate into a key to be pressed.
        if action2 <= len(charlist) and action2 > 0:
            action2_neu=charlist[action2]
            action2=str(action2)
            action2=action2_neu
        else:
            action2="None"
    else:                          # this means it is the other way round: the neural network wants to be fed something it can digest
        # where will the mouse go?
        # problem here: Apparently, action is a string now, of format "[[0,0],None,None]."  WTF? WHY?

        action0=[[float(action0[0]),float(action0[1])]] # getting rid of some brackets here
        # the mousebutton to be pressed.
        # now we turn one of  "left", "middle", "right" or "None" into a number 0,1,2, or 3.
        if action1=="left":
            action1=0.5
        else:
            if action1=="middle":
                action1=1.5
            else:
                if action1=="right":
                    action1=2.5
                else:
                    action1=3.5
        action1=float(action1)
        if action2 != "None":
            action2=charlist.index(action2)
        else:
            action2=0
    action=(action0,action1,action2)
    return action


def action_selector(task,current_screen):        # selects the next action based on the current screen
                                                 # action (which is also a policy) is a tuple of :
                                                 # moveTo (x,y) 
                                                 # click (button)
                                                 # press (one charactrer from charlist)
    state=determine_state(current_screen)
    current_state=state
    if random.random() <= epsilon:
        action=choose_random_action()
    else:
        task_image=image_read(task)
        current_screen_image=image_read(current_screen)
        input_image_array=image_merge(task_image,current_screen_image)
        action=action_selector_net.predict(input_image_array)
        action=translate_action(action)
    return action

def do_it(state,action): #reads the action list and carries it out.
    pyautogui.moveTo([action[0][0],action[0][1]])
    if action[1] != "None":
        pyautogui.click(button=action[1])          
    if action[2] != "None":
        pyautogui.press(action[2])                                                     
    # save action in current actionlist:
    global actionlist       
    actionlist.update({state:((action[0][0],action[0][1]),action[1],action[2])})


def get_current_screen(program_instance,tasknumber,counter):                                  # putscurrent screen in filename, returns filename
    savename="screenshots/"+str(program_instance)+"-"+str(tasknumber)+"-"+str(counter)+".png"  # defines the name of the next screenshot
    current_screen=pyautogui.screenshot(savename)                                                    # saves the current screen for later use.
    return savename                                                                                  # gives back path and filename of screenshot


# main program starts here
pyautogui.FAILSAFE = False
time=str(datetime.datetime.now())
print ("PROGRAM started at ",time)
for directory in ["screenshots/","states/","target_folder/"]:
    if os.listdir(directory) != []:
        for files in os.listdir(directory):
            os.remove(directory+files)
q_table=collections.OrderedDict()                                                 # These are two ordered dictionaries of shape 
recent_q_table=collections.OrderedDict()                                          # {task1: {state_1:(action_1:qvalue_1), (action_2:qvalue_2), 
                                                                                  # action_3,...action_n),state_2:()} state_2:... state_n}, 
                                                                                  # task_2, 
                                                                                  # with action_n being of shape (move_to, click, press, reward)
                                                                                  # this one gets updated every time an action 
                                                                                  # is taken. the "recent" version only contains stuff for the
                                                                                  # current cycle and is reset after training.
screensize=pyautogui.size()
x=600                                                                            # Defines how large are the screenshots after reading them from
y=338                                                                             # the files that have been stored to the disk.
likeness=1000000                                                                  # a measure for how similar two images have to be 
                                                                                  # to be considered the same state, derived from observations.
charlist=[' ', '!', '"', '#', '$', '%', '&', "'", '(',                            # a list of keys we could possibly press
        ')', '*', '+', ',', '-', '.', '/', '0', '1', '2', '3', '4', '5', '6', '7',
        '8', '9', ':', ';', '<', '=', '>', '?', '@', '[',']', '^', '_', '`',
        'a', 'b', 'c', 'd', 'e','f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o',
        'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '{', '|', '}', '~',
        'backspace', 'clear', 'ctrl', 'ctrlleft', 'ctrlright', 'del', 'delete',
        'divide', 'down', 'enter', 'esc', 'escape', 'execute', 'f1', 'f10',
        'f11', 'f12', 'f2', 'f3', 'f4', 'f5', 'f6', 'f7', 'f8', 'f9',
        'left','return', 'right', 'space', 'subtract', 'tab', 'up']
actionlist=collections.OrderedDict()                                              # This is a dictionary of actions that reads like 
                                                                                  # {statename_1:action_1}, {statename_1:action_2},... 
                                                                                  # {statename_n:action_n}]
                                                                                  # this one gets appended when an action is taken, 
                                                                                  # and reset every time a task is achieved. 
program_instance = int(random.random()*4294967296)                                # A probably unique number for this program's run, 
                                                                                  # used for identifying screenshots later.
path="tasks/"                                                                     # path of the task files
taskfiles = sorted(os.listdir(path))                                              # read names of files that describe our tasks into a list
for task in taskfiles:                                                            # and initialize the q_table and the recent_q_table
    q_table.update({task:{}})
    recent_q_table.update({task:{}})
tasks=[]                                                                          # Initialize the tasks list
epsilon=1.0                                                                       # initialize epsilon ro RL, set it to 1.  set to 0 for testing
                                                                                  # So initially, we act completely randomly.
counter=-1                                                                        # for naming the classifier mode savefile...
action_selector_net=action_selector_definition()                                  # define the action_learner
for task in taskfiles:                                                            # work through all tasks.
    success=False                                                                 # At start of a task, we probably haven't succeeded yet.
    counter=-1                                                                    # To be used later in the while loop.
    while success==False:                                                         # for each task, work until the task is done.
        counter += 1                                                              # increase the counter.
        current_screen=get_current_screen(program_instance,task,counter)          # make a screenshot of the current screen.
        success=success_detector(task,current_screen)                             # check if we have already reached our goal
        state=determine_state(current_screen)                                     # do we have a state that is equivalent to our current screen?
                                                                                  # if we do, that's our state; 
                                                                                  # if not, our current screen is a new state
        if success==False:                                                        # if we are not done yet:
            action=action_selector(path+task,current_screen)                      # choose to do something that might improve our situation 
            do_it(state,action)                                                   # carry out that action.
        if success == True:                                                       # if we are successful:
            shutil.copy(current_screen,"target_folder/")                          # save current screen to target folder
        if counter % 20==0 and counter > 0:                                        # every 20 cycles, train nn with q_table, tasks and states.
            print ("Counter: ",counter)
            train_selector(action_selector_net)                                   # train selector with current q_table
            epsilon=epsilon*0.9                                                   # and reduce epsilon to 90% of current value.
            print ("Epsilon:",epsilon) # for dev purposes
time=str(datetime.datetime.now())
print ("PROGRAM ended at ",time)
