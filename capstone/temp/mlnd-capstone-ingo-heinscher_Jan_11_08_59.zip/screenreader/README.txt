# How to run the program#

In order to run the program, a number of preparation steps should be performed:

1. Create a new user on a computer you won‘t need for quite a while – this will prevent the program to accidentally delete any of your own data. Ideally, the computer that you use can be accessed remotely, for example using SSH.

2. Copy the program and its complete folder structure to a directory accessible by that user. Pay special considereation to whether you want to use the pre-trained models provided (which are the result of a hundred hours or so of the program running) or if you want to empty the saved_models folder to start from scratch. The pre-trained models are not sufficiently trained to produce useful results. To not use them, simply copy all files in ./saved_models to the ./saved_models/old subfolder.

3. Also, the task files provided are examples that may not be applicable to your testing computer – check this and if necessary, replace the task files with screenshots of your own making before running the program.

4. The libraries required for this project are: PIL, glob, pyautogui, keras, numpy, os, cv2, matplotlib, random, shutil, sklearn, h5py, collections, datetime, json

5. On Windows, launch screenreader.py from a Powershell ISE window. Resize that window to a very small size, launch the program (using the command „python3 screeenreader.py“), then minimize the Powershell ISE window. This reduces the probability of the program stopping itself. Using a CMD window would potentially make the program pause itself when it randomly clicks into its own CMD window, so don‘t do that. On a linux machine, simply resize minimze the terminal window that you use to run the program.

6. If you want to see results, wait for a few days. If you merely want to check if everything works, wait for about an hour, after the first 200 actions have been carried out and the training of the neural networks commences for the first time.

7. If you want to check the progress of the program, you can ssh into the machine you are using to run the program and check the logfile in ./logs and type (on Windows) or cat (on Linux and the like) that logfile to see what is happening.
