import keras
from keras.preprocessing import image
import sys
import numpy


def image_read(image_path):  # reads in an image and turns it into a numpy array.
    image=keras.preprocessing.image.load_img(image_path,grayscale=True,target_size=(x,y))
    image=keras.preprocessing.image.img_to_array(image,"channels_last")
    return image

def image_distance(image_path1,image_path2): # computes how similar two given images are and gives back a value between 0 and roughly 
    sum_of_differences=0 # initialize
    image1=image_read(image_path1)
    image2=image_read(image_path2)
    for x1 in range(0,x):
        for y1 in range(0,y):
            difference=image1[x1][y1]-image2[x1][y1]
            difference=abs(difference)            
            sum_of_differences+=difference
    return sum_of_differences

#main program

arguments=sys.argv

x=1024
y=576


image1=arguments[1]
image2=arguments[2]

distance=image_distance(image1,image2)

print ("These two images have a distance of ",distance)



