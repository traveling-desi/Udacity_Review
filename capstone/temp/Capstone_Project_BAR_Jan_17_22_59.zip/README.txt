Machine Learning Capstone README

The software used to develop the smog test project includes:
1. Python 3.6
2. Jupyter Notebook
3. Various sklearn libraries
4. Pandas and numpy
5. XGBoost- the final solution does not involve XGB
6. Keras, with a tensorflow backend- the final solution does not involve Keras
7. Imblearn for imbalanced learning functions

No proprietary software was utilized.
