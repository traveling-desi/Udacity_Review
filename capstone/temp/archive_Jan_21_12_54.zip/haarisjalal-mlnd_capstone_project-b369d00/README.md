# mlnd_capstone_project
Final thesis for the capstone project

I used the jupyter notebook. The code was written in python. The libraries were mostly keras and tensorflow.

The images were taken from https://www.kaggle.com/c/the-nature-conservancy-fisheries-monitoring/data

