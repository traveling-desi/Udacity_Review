# OIC-classification
Document feature based classification of Canadian Orders in Council

__Summary__
Many government decisions or directives in Canada are published through Orders in Council. These contain important information about the workings of government, but their volume, and limited tagging and search capability make them difficult and time consuming to review, and distract from their utility. This project demonstrates the ability to use unsupervised clustering to group summaries of Canadian Orders in Council into relevant categories, enhancing the ability to search and extract information from this dataset. 

![image](https://github.com/rbitr/OIC-classification/blob/master/OIC%20Topics.png?raw=true)

__Report__
The report is contained in the report.pdf file in the root directory

__Supplementary information__

The Supplementary Information folder contains 
* python code used for pulling the OICs from the Privy Council website ( 'gic_load.py' and ' gic_load_2016.py' )
* The dataset used that was pulled down using the code above: training set - 'oics_2017.pckl'; validation set - 'oics_2016.pckl'
* The project code, in Jupyter Notebook and html format 'OIC_analysis'
* Three appendices containing output that was used to estimate the accuracy of the clustering
* The original proposal, proposal.pdf
* The review of the proposal, Proposal Review.pdf

__Running the code__

The OICs have already been pre-downloaded inthe pckl files and the gid_load files do not need to be re-run. The following libraries are used by the Notebook:

* pickle
* numpy
* sklearn (various)
* pandas
* matplotlib
* itertools
* operator
