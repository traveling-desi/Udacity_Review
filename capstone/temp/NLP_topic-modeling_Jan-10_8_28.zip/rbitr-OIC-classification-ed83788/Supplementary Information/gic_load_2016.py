# -*- coding: utf-8 -*-
"""
Created on Tue Jan 02 08:13:12 2018
pulls OICs from the Privy Council Website and saves a dictionary using pickle
@author: amarble
"""

import requests
from bs4 import BeautifulSoup
from time import sleep

oics = []
for num in range (1,100): #99 samples for testing

    # search URL with str(num).zfill(4) as the particular OIC to fetch
    r = requests.get('http://www.pco-bcp.gc.ca/oic-ddc.asp?lang=eng&Page=secretariats&txtOICID=2016'+str(num).zfill(4)+'&txtFromDate=&txtToDate=&txtPrecis=&txtDepartment=&txtAct=&txtChapterNo=&txtChapterYear=&txtBillNo=&rdoComingIntoForce=&DoSearch=Search+%2F+List')
    
    data = r.text # get the URL text
    
    soup = BeautifulSoup(data,'html.parser') # parse with beautiful soup
    tables = soup.find_all('table') # extract the table of OICs
    
    # all releveant fields in the OIC (number, date, precis, have a header tag)
    my_dict = {}
    for d in tables[0].find_all('td'):
        if (d.has_attr('headers')):
            my_dict[d['headers'][0]]=d.text
            if(d['headers'][0][:11]=='attachments'): # stop when the 'attachements' section of the first OIC has been reached - a heuristic for knowing when we're done
                break
    oics.append(my_dict)
    sleep(1) # crawl delay
    print(num)
    
# save 
import pickle  
fil = open('oics_2016.pckl', 'wb')
pickle.dump(oics,fil)
fil.close()