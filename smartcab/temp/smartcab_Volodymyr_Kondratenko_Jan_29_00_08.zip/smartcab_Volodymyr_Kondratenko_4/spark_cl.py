from __future__ import print_function
import argparse
import yaml
import re

from pyspark import SparkConf, SparkContext

from pyspark.sql import SparkSession, Window
from pyspark.sql.functions import *
from pyspark.sql.types import *
import itertools

spark = SparkSession.builder \
    .appName('data pipeline') \
    .config('spark.driver.memory', '8G') \
    .config('spark.executor.memory', '8G') \
    .config('spark.executor.cores', '8') \
    .config('spark.yarn.executor.memoryOverhead', '2048') \
    .enableHiveSupport() \
    .getOrCreate()



'''
Template:
dfs = BaseDF().basedf(args.analysis, args.window)

# Calculate entropy columns
entropy_df = dfs['by_account_total'].join(dfs['by_account_window'], on = 'joining_account_number')

dfs['by_account_total'] = dfs['by_account_total'].join(Entropy('watch_time_ms').entropy(entropy_df), on = 'joining_account_number')\
    .join(Entropy('watch_time_on_net_ms').entropy(entropy_df), on = 'joining_account_number')\
    .join(Entropy('watch_time_off_net_ms').entropy(entropy_df), on = 'joining_account_number')

# Join together all the agg tables
df = dfs['by_account_total'].select('joining_account_number')

account_level = ['by_account_total', 'by_account_avg', 'by_account_pivot_application_type', 'by_account_pivot_playback_type', 'by_account_pivot_start_weekday']
account_level_df = map(lambda k: df.join(dfs[k], on = 'joining_account_number'), account_level)

'''

test1=[1, 2, 3]
test2=[1, 4, 7]
test3 = [1, 4, 6]

df_test = spark.createDataFrame(zip(test1, test2, test3), ["test1","test2","test3"])
df_test.agg(corr("test1","test2").alias('a_b'),corr("test1","test3"), corr("test3","test2")).collect()

df_test.columns
# out ['test1', 'test2', 'test3']

def convert_str(i):
    return 'corr(\'{0}\',\'{1}\').alias(\'corr_{0}_{1}\')'.format(i[0],i[1])

>>> print(map(convert_str, list(itertools.combinations(df_test.columns, 2))))
# out ["corr('test1','test2').alias('corr_test1_test2')", "corr('test1','test3').alias('corr_test1_test3')", "corr('test2','test3').alias('corr_test2_test3')"]
# map may not work here. would need to use lambda instead

df_test.agg(map(convert_str, list(itertools.combinations(df_test.columns, 2)))).collect()

df_test.agg(map(lambda i: ('corr(\'{0}\',\'{1}\').alias(\'{0}_{1}\')'.format(i[0],i[1])), list(itertools.combinations(df_test.columns, 2)))).collect()

aggList1 =  [mean(col).alias(col + '_m') for col in df.columns]

#how to pass
#>>> print(map(lambda i:'corr(\'{0}\',\'{1}\').alias(\'corr_{0}_{1}\')'.format(i[0],i[1]), list(itertools.combinations(df_test.columns, 2))))
#["corr('test1','test2').alias('corr_test1_test2')", "corr('test1','test3').alias('corr_test1_test3')", "corr('test2','test3').alias('corr_test2_test3')"]
#to
#.agg
#df_test.agg(corr("test1","test2").alias('a_b'), corr("test1","test3")).collect()
#[Row(a_b=1.0, corr(test1, test3)=0.9933992677987827)]

#exprs = {x: "sum" for x in df.columns}
#aggList =  [corr('sal', col).alias(col) for col in df.columns]
#>>> aggList1 =  [corr(i[0],i[1]).alias(i[0] +'_'+i[1]) for i in list(itertools.combinations(df_test.columns, 2))]
#>>> df3=df_test.agg(*aggList1)
#>>> df3.head(5)
#[Row(test1_test2=1.0, test1_test3=0.9933992677987827, test2_test3=0.9933992677987828)]

list = [df3.rdd.map(lambda x: x[yo]).first() for yo in df3.columns]

create a 2d array from here
