# Machine Learning Nanodegree on Udacity

**Make Predictive Models**

[Instructors:](https://www.udacity.com/us) Sebastian Thrun, Michael Littman, Charles Isbell, Katie Malone


## Introduction

This repo contains all my work for the Machine Learning Nanodegree offered by Udacity. All the base code is taken from [Machine Learning Nanodegree on Udacity](https://www.udacity.com/course/machine-learning-engineer-nanodegree--nd009). All content for this course was developed by Georgia Tech, Udacity, Google and Kaggle.

## Project Outline

### [Project 0: Exploring Pandas and Numpy - Titanic Survival Exploration](https://github.com/dsiker/machine-learning-nanodegree/blob/master/project0-titanic-survival-exploration/titanic_survival_exploration.ipynb)
Built a decision function that predicts survival outcomes from the 1912 Titanic disaster based on each passenger’s features, such as sex and age.

### [Project 1: Model Evaluation and Validation - Predicting Boston Housing Prices](https://github.com/dsiker/machine-learning-nanodegree/blob/master/project1-predicting-boston-housing-prices/boston_housing.ipynb)
Built a model to predict the value of a given house in the Boston real estate market using various statistical analysis tools. Identified the best price that a client can sell their house utilizing machine learning.

### [Project 2: Supervised Learning - Finding Donors for CharityML](https://github.com/dsiker/machine-learning-nanodegree/blob/master/project2-finding-donors-for-CharityML/finding_donors.ipynb)
Investigated factors that affect the likelihood of charity donations being made based on real census data. Developed a naive classifier to compare testing results. Trained and tested several supervised machine learning models on preprocessed census data to predict the likelihood of donations. Selected the best model based on accuracy, a modified F-scoring metric, and algorithm efficiency.

### [Project 3: Unsupervised Learning - Creating Customer Segments](https://github.com/dsiker/machine-learning-nanodegree/blob/master/project3-customer-segments/customer_segments.ipynb)
Reviewed unstructured data to understand the patterns and natural categories that the data fits into. Used multiple algorithms and both empirically and theoretically compared and contrasted their results. Made predictions about the natural categories of multiple types in a dataset, then checked these predictions against the result of unsupervised analysis.

### [Project 4: Reinforcement Learning - Train a Smartcab to Drive](https://github.com/dsiker/machine-learning-nanodegree/blob/master/project4-smartcab/smartcab.ipynb)

### [Project 5: Deep Learning - Dog Breed Classifier]()

### [Project 6: Capstone Project]()





