# smartcab
Udacity ML Nanodegree Reinforcement Learning Project

This project includes usage of a Q-Learner to teach a digital smartcab how to drive both safely and efficiently.

Please see the [iPython/Jupyter notebook](https://github.com/mvirgo/smartcab/blob/master/smartcab.ipynb) included in this repository for further details over this project.
