# smartcab
The completed Smartcab project for Udacity Machine Learning course.
