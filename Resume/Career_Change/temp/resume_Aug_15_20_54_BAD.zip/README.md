Interactive Resume
==================

Original code part of project 2 from Udacity's Front End Web Development Nanodegree.
This represents my online resume that was created for project 2.

Resume hosted on github at [cherylcourt.github.io/resume](http://cherylcourt.github.io/resume/)
