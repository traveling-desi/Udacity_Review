# Kevin Lazich resume

## Here is my resume in some formats

* Adobe Acrobat Document - [resume.pdf](resume/resume.pdf)
* Office Open XML Document - [resume.docx](resume/resume.docx)
* OpenDocument Text - [resume.odt](resume/resume.odt)
* Javascript Object Notation File - [resume.json](resume/resume.json) _see [jsonresume.org](https://jsonresume.org/)_
* Plain Text Document - [resume.txt](resume/resume.txt)
* Chrome HTML Document - [resume.html](resume/resume.html)
* Rich Text Document - [resume.rtf](resume/resume.rtf)
* EPUB File [resume.epub](resume/resume.epub)
* Google Drive Link - [resume](https://docs.google.com/document/d/1U-5vi4dFznXCPI5mebmaHCWdhOq4VmLYwbmaH6dMJMU/edit?usp=sharing)
